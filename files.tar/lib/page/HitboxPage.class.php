<?php
namespace wcf\page;
use wcf\system\user\collapsible\content\UserCollapsibleContentHandler;
use wcf\system\WCF;

/**
 * Integrates a hitbox group.
 * 
 * @author	Chrisblue
 * @copyright	2014 gamecaster.de
 * @license	CC Attribution 4.0 International <http://creativecommons.org/licenses/by/4.0/legalcode>
 * @package	com.gamecaster.wcf.hitboxpage
 */
class HitboxPage extends AbstractPage {

public $activeMenuItem = 'wcf.page.hitbox';
public $templateName = 'hitbox';

	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'sidebarCollapsed' => UserCollapsibleContentHandler::getInstance()->isCollapsed('com.woltlab.wcf.collapsibleSidebar', 'com.gamecaster.wcf.HitboxSide'),
			'sidebarName' => 'com.gamecaster.wcf.HitboxSide',
			'allowSpidersToIndexThisPage' => true
		));
	}
}