<?php
namespace wcf\system\dashboard\box;
use wcf\data\dashboard\box\DashboardBox;
use wcf\page\IPage;
use wcf\system\event\EventHandler;
use wcf\system\WCF;

/**
 * Hitbox dashboard box.
 * 
 * @author	Chrisblue
 * @copyright	2014 Game Caster
 * @license	CC Attribution 4.0 International <http://creativecommons.org/licenses/by/4.0/legalcode>
 * @package	com.gamecaster.wcf.hitbox
 * @subpackage	system.dashboard.box
 * @category	Community Framework
 */
class HitboxDashboardBox extends AbstractContentDashboardBox {
	/**
	 * displayed online status
	 * @var	\wcf\system\cache\builder\UserStatsCacheBuilder
	 */
	 
	 	protected function render() {
			return WCF::getTPL()->fetch('hitbox_check');
	}
	
}
