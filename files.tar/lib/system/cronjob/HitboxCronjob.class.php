<?php namespace wcf\system\cronjob;

use wcf\system\WCF;
use wcf\data\cronjob\Cronjob;
use wcf\system\cronjob\AbstractCronjob;

/**
 * @author	Chrisblue
 * @copyright	2014 Game Caster
 * @license	CC Attribution 4.0 International <http://creativecommons.org/licenses/by/4.0/legalcode>
 * @package	com.gamecaster.wcf.hitboxpage
 */
class HitboxCronjob extends AbstractCronjob {

	public function execute(Cronjob $cronjob) {
		parent::execute($cronjob);
		
		$path = WCF_DIR."templates/";
		
		$write = '<nav class="tabMenu"><ul id="chatchange">';

$user = json_decode(file_get_contents('http://api.hitbox.tv/team/'.HITBOX_TEAM,true));

foreach($user->members as $member)
{

$live = json_decode(file_get_contents('http://api.hitbox.tv/media/live/'.$member->user_name), true);

$write .= "<li ";
if ($live['livestream'][0]['media_is_live'] == 1) {$write .= "class='hitboxactive'"; }
$write .= ">";
$write .= "<a href='index.php/streams/#".$member->user_name."' data-toggle='tab'><img width='60' height='60' class='framed' src='http://edge.vie.hitbox.tv".$member->user_logo."'/> ".$member->user_name." ";

if ($live['livestream'][0]['media_is_live'] == 0) {
$write .= '<span class="badge badgeUpdate">Offline</span>';
}else{
$write .= '<span class="badge">Online</span>';
}

$write .= "</a></li>";
}

$write .= "</ul></nav>";

foreach($user->members as $member)
{

$live = json_decode(file_get_contents('http://api.hitbox.tv/media/live/'.$member->user_name), true);
$follow = json_decode(file_get_contents('http://api.hitbox.tv/followers/user/'.$member->user_name), true);

$write .= "<div class='container containerPadding marginTop tabMenuContent ";
if ($live['livestream'][0]['media_is_live'] == 1) { $write .= "active"; }
$write .= "' id='".$member->user_name."'>";

if ($live['livestream'][0]['media_is_live'] == 1) {
  $write .= "<section><iframe style='width:100%' height='640' src='http://hitbox.tv/#!/embed/".$member->user_name."?autoplay=false' frameborder='0' allowfullscreen></iframe></section>";
  //$write .= "<div class='well well-sm'>Zuschauer: ".$live['livestream'][0]['media_views']."</div>";
}else{
$write .= "<a class='framed' href='http://www.hitbox.tv/".$member->user_name."'><img style='margin:1em;float:left;' src='http://edge.vie.hitbox.tv".$member->user_logo."'/></a>";
  $write .= "<header class='boxHeadline'><h1>".$member->user_name.WCF::getLanguage()->get('wcf.page.hitbox.isoffline')."</h1></header>";
  $write .= "<p>".WCF::getLanguage()->get('wcf.page.hitbox.offlinemessagea').$member->user_name.WCF::getLanguage()->get('wcf.page.hitbox.offlinemessageb')."</p>";
  $write .= "<p><br /><a href='http://www.hitbox.tv/".$member->user_name."'><button>".$member->user_name.WCF::getLanguage()->get('wcf.page.hitbox.channel')."</button></a></p>";
$write .= "<div style='clear:both'></div>";

if(HITBOX_SHOW_DESC) {$write .= "<p>".$live['livestream'][0]['media_description']."</p>"; }

$write .= "<div class='boxHeadline'><h1>".WCF::getLanguage()->get('wcf.page.hitbox.follower')." <span class='badge'>".$live['livestream'][0]['channel']['followers']."</span></h1></div>";

$i = 0;
if(HITBOX_SHOW_FOLLOWER) {
$write .= "<div class='container marginTop'><ol class='containerList doubleColumned userList'>";

while($i < $live['livestream'][0]['channel']['followers']) {
$write .= "<li><div class='box48'>";
$write .= "<a class='framed' href='http://www.hitbox.tv/".$follow['followers'][$i]['user_name']."'><img class='media-object' src='http://edge.vie.hitbox.tv".$follow['followers'][$i]['user_logo_small']."' alt='...'></a>";
$write .= "<div class='details userInformation'><div class='containerHeadline'><h3>".$follow['followers'][$i]['user_name']."</h3></div></div>";
$write .= "</div></li>";
$i++;
}

$write .= "</ol></div>"; }

}

$write .= "</div>";
}

file_put_contents($path.'hitbox_out.tpl',$write);

// Hitbox Check

$write = '';

$user = json_decode(file_get_contents('http://api.hitbox.tv/team/'.HITBOX_TEAM,true));

foreach($user->members as $member)
{

$live = json_decode(file_get_contents('http://api.hitbox.tv/media/live/'.$member->user_name), true);

if ($live['livestream'][0]['media_is_live'] == 1) {
$write .= "<div class='container containerPadding marginTop htmlContent'>";
$write .= "<div class='framed'><img width='100' src='http://edge.vie.hitbox.tv".$member->user_logo."' style='float:left;margin-right:1em' /></div>";
$write .= "<header class='boxHeadline'><h1>".$member->user_name.WCF::getLanguage()->get('wcf.page.hitbox.islive').$live['livestream'][0]['media_status']."</h1></header>";
$write .= "<a class='button buttonPrimary' href='".WCF_DIR."page/hitbox/#".$member->user_name."'><span class='icon icon16 icon-play'></span> ".WCF::getLanguage()->get('wcf.page.hitbox.letssee')."</a>";
$write .= "<div style='clear:both'></div></div>";

if (HITBOX_SHOW_AUDIO){ $write .= "<audio style='display:none' src='".HITBOX_AUDIO."' autoplay></audio>";}
}}

file_put_contents($path.'hitbox_check.tpl',$write);

	}
}